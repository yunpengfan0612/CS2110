#ifndef ENEMY_BITMAP_H
#define ENEMY_BITMAP_H
extern const unsigned short enemy[100];
#define ENEMY_WIDTH 10
#define ENEMY_HEIGHT 10
#endif