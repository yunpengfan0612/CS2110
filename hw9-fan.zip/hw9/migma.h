#ifndef MIGMA_BITMAP_H
#define MIGMA_BITMAP_H
extern const unsigned short migma[38400];
#define MIGMA_WIDTH 240
#define MIGMA_HEIGHT 160
#endif