#ifndef BEGIN_BITMAP_H
#define BEGIN_BITMAP_H
extern const unsigned short begin[38400];
#define BEGIN_WIDTH 240
#define BEGIN_HEIGHT 160
#endif