#ifndef USER1_BITMAP_H
#define USER1_BITMAP_H
extern const unsigned short user1[100];
#define USER1_WIDTH 10
#define USER1_HEIGHT 10
#endif