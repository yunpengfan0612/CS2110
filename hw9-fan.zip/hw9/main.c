#include <stdlib.h>
#include <stdio.h>
#include "myLib.h"
#include "text.h"
#include "begin.h"
#include "migma.h"
#include "user1.h"
#include "gameover.h"
#include "youwin.h"
#include "enemy.h"


void welcomeScreen();
void gameScreen();
void winScreen();
void loseScreen();

enum SCREEN screen = WELCOMESCREEN;

int main() {
	//set dispy mode
	(REG_DISPCNT) = (BG2_ENABLE) | (MODE3);

	//screen case switcher
	while(TRUE) {
		switch (screen) {
			case WELCOMESCREEN:
				welcomeScreen();
				break;
			case GAMESCREEN:
				gameScreen();
				break;
			case WINSCREEN:
				winScreen();
				break;
			case LOSESCREEN:
				loseScreen();
				break;

		}
		WaitForVblank();
	}
	return FALSE;
}

void welcomeScreen() {
	//display begin screen
	drawImage3(0, 0, 240, 160, begin);
	drawStr(80, 60,"Press enter to start!", WHITE);
	while(!KEY_DOWN_NOW(BUTTON_START));
	//if press ENTER, switch to GAMESCREEN
	screen = GAMESCREEN;	
}

void gameScreen() {
	//draw background
	drawImage3(0, 0, 240, 160, migma);

	//set up jump out condition
	int run = 1;

	//initialize player
	USER player;
	initializeUser(&player);

	//set up timing
	int count = 50;
	int timeLeft = 50;
	//char timer pointer
	char pt[2]; 

	//create and initialize moving object as "enemy" in game
	MOVREC enemy1[3];
	MOVREC enemy2[3];

	initializeEnemy(enemy1, 55, 20, 2);
	initializeEnemy(enemy2, 35, 210, -2);

	//start game playing
	while (run) {
		//timing counter
		count--;

		//draw map where player and enemy should playing in
		drawRect(130, 20, 15, 20, BLACK);
		drawRect(15, 200, 15, 20, BLACK);
		drawRect(30, 20, 100, 200, BLACK);

		//decrement timer(timeLeft)
		while(!count) {
			count = 50;
			timeLeft--;
		}

		//if don't win in set up timing, you lose
		if (timeLeft == 0) {
			run = 0;
			screen = LOSESCREEN;
		}

		//put int into char* as timer display
		pt[0] = (timeLeft / 10) + 0x30;
		pt[1] = (timeLeft % 10) + 0x30;

		//control user movement
		if (KEY_DOWN_NOW(BUTTON_LEFT)) {
			player.c -= 1;
		}

		if (KEY_DOWN_NOW(BUTTON_RIGHT)) {
			player.c += 1;
		}

		if (KEY_DOWN_NOW(BUTTON_UP)) {
			player.r -= 1;
		}

		if (KEY_DOWN_NOW(BUTTON_DOWN)) {
			player.r += 1;
		}

		//jump out if press BACKSPAACE
		if (KEY_DOWN_NOW(BUTTON_SELECT)) {
			screen = WELCOMESCREEN;
			break;
		}

		//draw player 
		drawImage3(player.r, player.c, USER1_WIDTH, USER1_HEIGHT, user1);
		//make sure player is moving inside of the map
		checkUserBounds(&player);

		//implement enemies
		int i;
		for (i = 0; i < 3; i++) {
			//set up auto movement
			enemy1[i].c += enemy1[i].cd;
			//draw enemy
			drawImage3(enemy1[i].r, enemy1[i].c, ENEMY_WIDTH, ENEMY_HEIGHT, enemy);
			//make sure enemy is moving inside of the map
			boundsCheck(&enemy1[i].c, &enemy1[i].cd);
			//check collision between player and enemy
			//jump out to LOSESCREEN if collision is TRUE
			if (checkCollision(player,&enemy1[i])) {
				run = 0;
				screen = LOSESCREEN;
			}

			//some enemies moving from opposed direction
			enemy2[i].c += enemy2[i].cd;
			drawImage3(enemy2[i].r, enemy2[i].c, ENEMY_WIDTH, ENEMY_HEIGHT, enemy);
			boundsCheck(&enemy2[i].c, &enemy2[i].cd);
			if (checkCollision(player, &enemy2[i])) {
				run = 0;
				screen = LOSESCREEN;
			}	
		}

		//display timer
		drawRect(140, 50, 10, 80, BLACK);
		drawStr(140, 50, "Time Left: ", WHITE);
		drawStr(140, 115, pt, WHITE);

		//if player move to win zone, he/she win.
		if (player.c > 201 && player.r <= (30 - USER1_HEIGHT)) {
			run = 0;
			screen = WINSCREEN;
		}

		//taking care of VBLANK
		WaitForVblank();
	}


}

void loseScreen() {
	//draw backgound of lose screen
	drawImage3(0, 0, 240, 160, gameover);
	drawStr(80, 60,"Press enter to try again!", WHITE);

	while(TRUE) {
		//jump to welcome/title screen if press BACKSPACE
		if (KEY_DOWN_NOW(BUTTON_SELECT)) {
			screen = WELCOMESCREEN;
			break;
		}
		//jump to game screen if press ENTER
		if (KEY_DOWN_NOW(BUTTON_START)) {
			screen = GAMESCREEN;
			break;
		}
		WaitForVblank();
	}

}

void winScreen() {
	//draw backgound of lose screen
	drawImage3(0, 0, 240, 160, youwin);
	drawStr(80, 60,"Press enter to try again!", BLUE);

	while(TRUE) {
		//jump to welcome/title screen if press BACKSPACE
		if (KEY_DOWN_NOW(BUTTON_SELECT)) {
			screen = WELCOMESCREEN;
			break;
		}
		//jump to game screen if press ENTER
		if (KEY_DOWN_NOW(BUTTON_START)) {
			screen = GAMESCREEN;
			break;
		}
		WaitForVblank();
	}
}