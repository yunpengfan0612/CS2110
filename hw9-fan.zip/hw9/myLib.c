#include "myLib.h"
#include "enemy.h"
#include "user1.h"
#include <stdlib.h>
#include <stdio.h>

//0x6000000: start of V RAM, where the data used for background, and sprites arestored
//consists of 240 x 160 16-bits shorts
u16 *videoBuffer = (u16 *)0x6000000;

void setPixel(int r, int c, u16 color) {
	videoBuffer[OFFSET(r, c, 240)] = color;
}

void drawRect(int row, int col, int height, int width, volatile u16 color)
{
	int r;
	for(r = 0; r < height; r++)
	{
		DMA[3].src = &color;
		DMA[3].dst = videoBuffer + OFFSET(row+r, col, 240);
		DMA[3].cnt = DMA_ON | DMA_SOURCE_FIXED | width;		
	}
}

void drawImage3(int r, int c, int width, int height, const u16* image) {
	int row;
	for(row = 0; row < height; row++)
	{
		DMA[3].src = image + width * row;
		DMA[3].dst = & videoBuffer[OFFSET(r + row, c, 240)];
		DMA[3].cnt = width | DMA_ON ; //count|mode
	}
}

//initialize user
void initializeUser(USER *player) {
	player->r = 135;
	player->c = 25;
}

void initializeEnemy(MOVREC *enemy, int row, int col, int velocity) {
	int i;
	for (i = 0; i < 3; i++) {
		enemy->r = row;
		enemy->c = col;
		enemy->cd = velocity;
		enemy++;
		row += 30;
	}
}

void drawChar(int r, int c, char ch, u16 color) {
	int row, col;
	for (row = 0; row < 8; row++) {
		for (col = 0; col < 6; col ++) {
			if (fontdata_6x8[OFFSET(row, col, 6) + ch * 48]) {
				setPixel(r + row, c + col, color);
			}
		}
	}
}

void drawStr(int r, int c, char *str, u16 color) {
	while (*str) {
		drawChar(r, c, *str++, color);
		c += 6;
	}
}



void WaitForVblank()
{
	while(SCANLINECOUNTER > 160);
	while(SCANLINECOUNTER < 160);
}

void boundsCheck(int *var, int *delta)
{
	if(*var < 22) {
		*var = 22;
		*delta = -*delta;
	}
	if(*var > 208) {
		*var = 208;
		*delta = -*delta;
	}
}

void checkUserBounds(USER *player) {
	if (player->c < 21) {
		player->c = 21;
	}
	if (player->c > (219 - 10)) {
		player->c = 209;
	}
	if (player->r > (144 - 10)) {
		player->r = 134;
	}
	if (player->r < 16) {
		player->r = 16;
	}
	if (player->r > (129 - 10) && player->c > (39 - 10) && player->c <= 40) {
		player->c = (39 - 10);
	}
	//check upper long bound
	if (player->c < 200 && player->r < 31) {
		player->r = 31;
	}
	//check lower long bound
	if (player->r > (129 - 10) && player->c > 40) {
		player->r = (129 - 10);
	}
}

int checkCollision(USER player, MOVREC *enemy) {
	if (abs(player.c - enemy->c) <= 10 && abs(player.r - enemy->r) <= 10) {
		return 1;
	} else {
		return 0;
	}	
}

int abs(int num) {
	if (num < 0) {
		return -num;
	} else {
		return num;
	}
}


